// Shared layout constants
export const SIDEBAR_WIDTH = 370; // in pixels
